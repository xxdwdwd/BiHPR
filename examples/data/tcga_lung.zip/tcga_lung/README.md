# TCGA Lung Analysis Inputs

This directory contains the processed inputs used by
`examples/TCGA_lung_real_data.ipynb` to reproduce the lung cancer analysis.

- `LUNG_data.csv` contains the sample identifier,
  `FEV1_PERCENT_REF_PREBRONCHOLIATOR`, `CancerType`, and RNA-seq expression
  measurements.
- `lung_coef.xlsx` contains the candidate-gene table used to identify the
  analysis features available in `LUNG_data.csv`.

The notebook selects genes by log-normalized expression variance and writes all
generated figures, estimates, and summaries outside this directory, under
`outputs/tcga_lung_real_data/`. No fitted results are versioned with the input
data.

The data are included for reproducibility of this repository's TCGA lung
analysis. Users should comply with the applicable TCGA data-use and attribution
requirements when reusing them.
